steamApiKey = "CHANGE_ME" -- FOR PROFILE PHOTOS
Discord_Webhook = "CHANGE_ME"